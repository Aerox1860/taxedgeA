import { apiClient } from "../../../core/api/apiClient";
import { Platform } from "react-native";
import type { CompanyDoc, CompanyRegistrationDraft } from "../types/registration.types";

type ApplicationResponse = { applicationId: string | number; applicationNumber?: string; status: string };
type RegistrationSummary = { id: number; applicationNumber: string; companyType: string; status: string; currentStep: number };
type RegistrationDetails = {
  application: RegistrationSummary;
  companyDetails: Record<string, any>;
  registeredOffice: Record<string, any>;
  persons: any[];
  capital: Record<string, any>;
  shareholdings: any[];
  documents: any[];
  linkedRegistrations: Record<string, boolean>;
  payments: any[];
  tracking: any[];
};

export const companyRegistrationApi = {
  createOrUpdate: async (applicationId: string | number | undefined, companyType: string, currentStep: number) =>
    apiClient.post<RegistrationSummary>("/api/v1/company-registrations", {
      companyType,
      currentStep,
      ...(applicationId ? { applicationId: Number(applicationId) } : {}),
    }),
  list: async () => apiClient.get<RegistrationSummary[]>('/api/v1/company-registrations'),
  get: async (applicationId: string | number) =>
    apiClient.get<RegistrationDetails>(`/api/v1/company-registrations/${applicationId}`),
  saveCompanyDetails: async (applicationId: string | number, company: CompanyRegistrationDraft["company"]) =>
    apiClient.put(`/api/v1/company-registrations/${applicationId}/details`, {
      industryCategory: company.industryCategory,
      businessActivityDescription: company.businessActivityDescription,
      companyClass: company.companyClass,
      companyCategory: company.companyCategory,
      companySubCategory: company.companySubCategory,
      primaryActivity: company.primaryActivity,
      nicCode: company.nicCode,
      secondaryActivity: company.secondaryActivity,
      proposedName1: company.proposedName1,
      proposedName2: company.proposedName2,
      proposedName3: company.proposedName3,
      nameSuffix: company.nameSuffix,
      nameAvailabilityStatus: company.nameAvailabilityStatus,
      companyEmail: company.companyEmail,
      companyMobile: company.companyMobile,
    }),
  saveRegisteredOffice: async (applicationId: string | number, company: CompanyRegistrationDraft["company"]) =>
    apiClient.put(`/api/v1/company-registrations/${applicationId}/registered-office`, {
      addressLine: company.registeredAddressLine,
      city: company.registeredCity,
      district: company.registeredDistrict,
      state: company.registeredState,
      pincode: company.registeredPincode,
      premisesOwnership: company.premisesOwnership,
      officeAddressProofName: company.officeAddressProofName,
      officeAddressProofUri: null,
      ownershipDocName: company.ownershipDocName,
      ownershipDocUri: null,
      ownerNocName: company.ownerNocName,
      ownerNocUri: null,
    }),
  persons: async (applicationId: string | number) =>
    apiClient.get<Record<string, any>[]>(`/api/v1/company-registrations/${applicationId}/persons`),
  addPerson: async (applicationId: string | number, person: Record<string, any>) =>
    apiClient.post<Record<string, any>>(`/api/v1/company-registrations/${applicationId}/persons`, person),
  updatePerson: async (applicationId: string | number, personId: string | number, person: Record<string, any>) =>
    apiClient.put<Record<string, any>>(`/api/v1/company-registrations/${applicationId}/persons/${personId}`, person),
  deletePerson: async (applicationId: string | number, personId: string | number) =>
    apiClient.delete<void>(`/api/v1/company-registrations/${applicationId}/persons/${personId}`),
  saveCapital: async (applicationId: string | number, company: CompanyRegistrationDraft["company"]) =>
    apiClient.put(`/api/v1/company-registrations/${applicationId}/capital`, {
      authorizedCapital: company.authorizedCapital,
      paidUpCapital: company.paidUpCapital,
      numberOfShares: company.numberOfShares,
      faceValuePerShare: company.faceValuePerShare,
    }),
  shareholdings: async (applicationId: string | number) =>
    apiClient.get<Record<string, any>[]>(`/api/v1/company-registrations/${applicationId}/shareholdings`),
  addShareholding: async (applicationId: string | number, shareholding: Record<string, any>) =>
    apiClient.post<Record<string, any>>(`/api/v1/company-registrations/${applicationId}/shareholdings`, shareholding),
  updateShareholding: async (applicationId: string | number, shareholdingId: string | number, shareholding: Record<string, any>) =>
    apiClient.put<Record<string, any>>(`/api/v1/company-registrations/${applicationId}/shareholdings/${shareholdingId}`, shareholding),
  deleteShareholding: async (applicationId: string | number, shareholdingId: string | number) =>
    apiClient.delete<void>(`/api/v1/company-registrations/${applicationId}/shareholdings/${shareholdingId}`),
  documents: async (applicationId: string | number) =>
    apiClient.get<Record<string, any>[]>(`/api/v1/company-registrations/${applicationId}/documents`),
  deleteDocument: async (applicationId: string | number, documentId: string | number) =>
    apiClient.delete<void>(`/api/v1/company-registrations/${applicationId}/documents/${documentId}`),
  saveLinkedRegistrations: async (applicationId: string | number, linkedRegistrations: CompanyRegistrationDraft["linkedRegistrations"]) =>
    apiClient.put(`/api/v1/company-registrations/${applicationId}/linked-registrations`, linkedRegistrations),
  review: async (applicationId: string | number) =>
    apiClient.get<RegistrationDetails>(`/api/v1/company-registrations/${applicationId}/review`),
  submitApplication: async (draft: CompanyRegistrationDraft) => {
    return apiClient.post<ApplicationResponse>(
      "/company-registration/apply",
      draft
    );
  },
  uploadDocument: async (applicationId: string | number, document: CompanyDoc) => {
    if (!document.fileUri) throw new Error(`File is missing for ${document.id}`);
    const form = new FormData();
    form.append("documentType", document.id);
    const fileName = document.fileName || `${document.id}.bin`;
    const mimeType = fileName.toLowerCase().endsWith(".pdf") ? "application/pdf" : "image/jpeg";
    if (Platform.OS === "web") {
      const fileResponse = await fetch(document.fileUri);
      if (!fileResponse.ok) throw new Error(`Unable to read selected file for ${document.id}`);
      form.append("file", await fileResponse.blob(), fileName);
    } else {
      form.append("file", { uri: document.fileUri, name: fileName, type: mimeType } as any);
    }
    return apiClient.post(`/api/v1/company-registrations/${applicationId}/documents`, form);
  },
  savePayment: async (applicationId: string | number, payload: {
    amount: number;
    governmentFee: number;
    professionalFee: number;
    totalAmount: number;
    paymentStatus: string;
    transactionId: string;
    paymentGateway: string;
    paymentMethod: string;
  }) => apiClient.post(`/api/v1/company-registrations/${applicationId}/payment`, payload),
  submitRegistration: async (applicationId: string | number) =>
    apiClient.post<ApplicationResponse>(`/api/v1/company-registrations/${applicationId}/submit`),
  checkNameAvailability: async (proposedName: string) => {
    return apiClient.get<{ available: boolean; similarNames: string[] }>(
      "/company-registration/check-name",
      { params: { name: proposedName } }
    );
  },
  fetchStatus: async (applicationId: string) => {
    return apiClient.get<{ status: string; currentStage: string }>(
      `/company-registration/status/${applicationId}`
    );
  },
};

export default companyRegistrationApi;
