import { create } from 'zustand';
import type { CompanyRegistrationDraft, LinkedRegistrations, CompanyDoc, CompanyDocumentType } from '../types/registration.types';
import type { CompanyType, CompanyDetails } from '../types/company.types';
import type { DirectorInfo, OpcNomineeInfo, PartnerInfo } from '../types/director.types';
import type { DocumentStatus } from '../../../types/domain';
import { companyRegistrationApi } from '../services/companyRegistrationApi';

interface CompanyRegistrationState {
  draft: CompanyRegistrationDraft;
  setCompanyType: (type: CompanyType) => void;
  updateCompanyDetails: (details: Partial<CompanyDetails>) => void;
  addDirector: (director: DirectorInfo) => void;
  updateDirector: (id: string, director: Partial<DirectorInfo>) => void;
  removeDirector: (id: string) => void;
  addPartner: (partner: PartnerInfo) => void;
  removePartner: (id: string) => void;
  setOpcNominee: (nominee: OpcNomineeInfo) => void;
  toggleLinkedRegistration: (key: keyof LinkedRegistrations) => void;
  updateDocumentStatus: (documentId: CompanyDocumentType, status: DocumentStatus, fileUri?: string, fileName?: string) => void;
  setStep: (step: number) => void;
  saveCurrentStep: (step: number) => Promise<void>;
  processPayment: (paymentMethod: string, applicationId?: string | number) => void;
  hydrateFromBackend: (applicationId?: string | number, stepOverride?: number) => Promise<void>;
  resetRegistration: () => void;
}

const createEmptyDraft = (): CompanyRegistrationDraft => ({
  id: '',
  company: {
    companyType: 'Private Limited',
    companyClass: 'Private',
    companyCategory: 'Company limited by Shares',
    companySubCategory: 'Indian Non-Government Company',
    primaryActivity: '',
    nicCode: '',
    secondaryActivity: '',
    proposedName1: '',
    proposedName2: '',
    nameSuffix: '',
    registeredAddressLine: '',
    registeredCity: '',
    registeredDistrict: '',
    registeredState: '',
    registeredPincode: '',
    premisesOwnership: 'Owned',
    companyEmail: '',
    companyMobile: '',
    authorizedCapital: 0,
    paidUpCapital: 0,
    numberOfShares: 0,
    faceValuePerShare: 0,
  },
  directors: [],
  partners: [],
  documents: [
    { id: 'DIRECTOR_PAN', name: 'PAN Card of all Directors / Promoters', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'DIRECTOR_ID_PROOF', name: 'Aadhaar / Passport / Voter ID', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'REGISTERED_OFFICE_PROOF', name: 'Registered Office Ownership / Lease Proof', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'OFFICE_UTILITY_BILL', name: 'Utility Bill (Electricity / Water)', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'PROPERTY_OWNER_NOC', name: 'Property Owner No Objection Certificate (NOC)', category: 'Office Proof', required: false, status: 'Pending' },
  ],
  linkedRegistrations: {
    pan: false,
    tan: false,
    gst: false,
    esic: false,
    epfo: false,
    professionalTax: false,
    bankAccount: false,
  },
  feeBreakdown: {
    professionalFee: 0,
    gstAmount: 0,
    statutoryCharges: 0,
    totalAmount: 0,
  },
  trackingStages: [],
  currentStep: 0,
  totalFee: 0,
  paymentStatus: 'Pending',
  status: 'Draft',
  createdAt: new Date().toISOString(),
});

const initialDraft: CompanyRegistrationDraft = {
  id: 'INC-2026-89421',
  company: {
    companyType: 'Private Limited',
    companyClass: 'Private',
    companyCategory: 'Company limited by Shares',
    companySubCategory: 'Indian Non-Government Company',
    primaryActivity: 'Information Technology & Software Services',
    nicCode: '62011',
    secondaryActivity: 'Data Processing & Hosting Services',
    proposedName1: 'TaxEdge Tech Private Limited',
    proposedName2: 'TaxEdge Financial Innovations Pvt Ltd',
    proposedName3: 'TaxEdge Solutions Private Limited',
    nameSuffix: 'Private Limited',
    nameAvailabilityStatus: 'Available',
    registeredAddressLine: 'Plot 42, Tech Park Phase 2, HITEC City',
    registeredCity: 'Hyderabad',
    registeredDistrict: 'Rangareddy',
    registeredState: 'Telangana',
    registeredPincode: '500081',
    premisesOwnership: 'Rented',
    companyEmail: 'contact@taxedgetech.com',
    companyMobile: '9876543210',
    officeAddressProofName: 'Electricity_Bill.pdf',
    officeAddressProofUri: '',
    ownershipDocName: 'Rent_Agreement_Office.pdf',
    ownershipDocUri: '',
    ownerNocName: 'Owner_NOC.pdf',
    ownerNocUri: '',
    authorizedCapital: 100000,
    paidUpCapital: 100000,
    numberOfShares: 10000,
    faceValuePerShare: 10,
  },
  directors: [
    {
      id: 'dir-1',
      name: 'Rajesh Kumar',
      pan: 'ABCDE1234F',
      aadhaar: '123456789012',
      dob: '1988-05-14',
      fatherName: 'Suresh Kumar',
      gender: 'Male',
      nationality: 'Indian',
      placeOfBirth: 'Hyderabad',
      occupation: 'Professional',
      educationalQualification: 'Post Graduate',
      designation: 'Director',
      category: 'Promoter Director',
      email: 'rajesh@taxedge.com',
      phone: '9876543210',
      hasDin: true,
      din: '08492014',
      hasDsc: true,
      sharesPercentage: 60,
      residentialAddress: 'Flat 302, Green Acres, Hyderabad',
      addressLine1: 'Flat 302, Green Acres, Road No 12',
      city: 'Hyderabad',
      district: 'Rangareddy',
      state: 'Telangana',
      pinCode: '500034',
      isResidentInIndia: true,
      sameAsPermanentAddress: true,
      numberOfShares: 6000,
      amountSubscribed: 60000,
      identityProofDocName: 'Aadhaar_Card_Rajesh.pdf',
      residentialAddressProofDocName: 'Passport_Rajesh.pdf',
    },
    {
      id: 'dir-2',
      name: 'Anita Sharma',
      pan: 'XYZPS9876K',
      aadhaar: '987654321098',
      dob: '1990-11-20',
      fatherName: 'Ramesh Sharma',
      gender: 'Female',
      nationality: 'Indian',
      placeOfBirth: 'Hyderabad',
      occupation: 'Business',
      educationalQualification: 'Graduate',
      designation: 'Director',
      category: 'Promoter Director',
      email: 'anita@taxedge.com',
      phone: '9812345678',
      hasDin: false,
      hasDsc: true,
      sharesPercentage: 40,
      residentialAddress: 'H.No 12-4, Jubliee Hills, Hyderabad',
      addressLine1: 'H.No 12-4, Jubilee Hills, Road No 36',
      city: 'Hyderabad',
      district: 'Hyderabad',
      state: 'Telangana',
      pinCode: '500033',
      isResidentInIndia: true,
      sameAsPermanentAddress: true,
      numberOfShares: 4000,
      amountSubscribed: 40000,
      identityProofDocName: 'Aadhaar_Card_Anita.pdf',
      residentialAddressProofDocName: '',
    },
  ],
  opcNominee: {
    name: 'Vikram Sharma',
    pan: 'NOMEE4321P',
    aadhaar: '456789123045',
    email: 'vikram.nominee@taxedge.com',
    phone: '9765432109',
    relationship: 'Brother',
  },
  partners: [],
  documents: [
    { id: 'DIRECTOR_PAN', name: 'PAN Card of all Directors / Promoters', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'DIRECTOR_ID_PROOF', name: 'Aadhaar / Passport / Voter ID', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'REGISTERED_OFFICE_PROOF', name: 'Registered Office Ownership / Lease Proof', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'OFFICE_UTILITY_BILL', name: 'Utility Bill (Electricity / Water)', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'PROPERTY_OWNER_NOC', name: 'Property Owner No Objection Certificate (NOC)', category: 'Office Proof', required: false, status: 'Pending' },
  ],
  linkedRegistrations: {
    pan: true,
    tan: true,
    gst: true,
    esic: true,
    epfo: true,
    professionalTax: true,
    bankAccount: true,
  },
  feeBreakdown: {
    professionalFee: 4999,
    gstAmount: 900,
    statutoryCharges: 1500,
    totalAmount: 7399,
  },
  trackingStages: [
    { id: 'stg-1', title: 'Draft Creation', description: 'Application initiated by user', status: 'completed', updatedAt: '18 Sep 2026' },
    { id: 'stg-2', title: 'KYC & Document Verification', description: 'Reviewing PAN, Aadhaar & Office Proofs', status: 'completed', updatedAt: '18 Sep 2026' },
    { id: 'stg-3', title: 'Under Review', description: 'TaxEdge compliance expert validation', status: 'current', updatedAt: 'In Progress' },
    { id: 'stg-4', title: 'Name Reservation (RUN / SPICe+ Part A)', description: 'Filing preferred names with MCA CRC', status: 'pending' },
    { id: 'stg-5', title: 'DSC & DIN Processing', description: 'Digital signature token generation', status: 'pending' },
    { id: 'stg-6', title: 'Ready for SPICe+ Part B Filing', description: 'Final incorporation payload compilation', status: 'pending' },
    { id: 'stg-7', title: 'Submitted to MCA Portal', description: 'Form e-MoA, e-AoA & AGILE-PRO-S filed', status: 'pending' },
    { id: 'stg-8', title: 'Government Approval & COI', description: 'Certificate of Incorporation & CIN Issuance', status: 'pending' },
  ],
  currentStep: 0,
  totalFee: 4999,
  paymentStatus: 'Pending',
  status: 'Draft',
  createdAt: '2026-09-18',
};

const mapBackendDraft = (data: any): CompanyRegistrationDraft => {
  const base = createEmptyDraft();
  const company = data.companyDetails || {};
  const office = data.registeredOffice || {};
  const capital = data.capital || {};
  const people = Array.isArray(data.persons) ? data.persons : [];
  const payments = Array.isArray(data.payments) ? data.payments : [];
  const payment = payments[0];

  return {
    ...base,
    id: String(data.application?.id || ''),
    company: {
      ...base.company,
      ...company,
      companyType: data.application?.companyType || company.companyType || base.company.companyType,
      registeredAddressLine: office.addressLine || '',
      registeredCity: office.city || '',
      registeredDistrict: office.district || '',
      registeredState: office.state || '',
      registeredPincode: office.pincode || '',
      premisesOwnership: office.premisesOwnership || 'Owned',
      officeAddressProofName: office.officeAddressProofName,
      officeAddressProofUri: office.officeAddressProofUri,
      ownershipDocName: office.ownershipDocName,
      ownershipDocUri: office.ownershipDocUri,
      ownerNocName: office.ownerNocName,
      ownerNocUri: office.ownerNocUri,
      authorizedCapital: Number(capital.authorizedCapital ?? company.authorizedCapital ?? 0),
      paidUpCapital: Number(capital.paidUpCapital ?? company.paidUpCapital ?? 0),
      numberOfShares: Number(capital.numberOfShares ?? company.numberOfShares ?? 0),
      faceValuePerShare: Number(capital.faceValuePerShare ?? company.faceValuePerShare ?? 0),
    } as CompanyRegistrationDraft['company'],
    directors: people.filter((person: any) => person.personType !== 'PARTNER' && person.personType !== 'NOMINEE').map((person: any) => ({
      ...person,
      id: String(person.id),
    })),
    partners: people.filter((person: any) => person.personType === 'PARTNER').map((person: any) => ({
      id: String(person.id), name: person.name, pan: person.pan, aadhaar: person.aadhaar || '', email: person.email, phone: person.phone || '',
      contributionAmount: Number(person.contributionAmount || 0), profitSharePercentage: Number(person.profitSharePercentage || 0),
      capitalContribution: Number(person.capitalContribution || 0), profitSharingRatio: Number(person.profitSharingRatio || 0),
    })),
    opcNominee: people.find((person: any) => person.personType === 'NOMINEE') ? (() => {
      const nominee = people.find((person: any) => person.personType === 'NOMINEE');
      return {
        name: nominee.name || '', pan: nominee.pan || '', aadhaar: nominee.aadhaar || '',
        email: nominee.email || '', phone: nominee.phone || '', relationship: nominee.relationship || '',
      };
    })() : undefined,
    documents: (Array.isArray(data.documents) ? data.documents : []).map((document: any) => ({
      id: document.documentType as CompanyDocumentType,
      name: document.name || document.documentType,
      category: document.category || '',
      required: Boolean(document.required),
      status: String(document.status).toUpperCase() === 'UPLOADED' ? 'Uploaded' : 'Pending',
      fileUri: document.fileUri,
      fileName: document.fileName,
    })) as CompanyDoc[],
    linkedRegistrations: { ...base.linkedRegistrations, ...(data.linkedRegistrations || {}) },
    feeBreakdown: {
      professionalFee: Number(payment?.professionalFee || 0),
      gstAmount: 0,
      statutoryCharges: Number(payment?.governmentFee || 0),
      totalAmount: Number(payment?.totalAmount || 0),
    },
    trackingStages: (Array.isArray(data.tracking) ? data.tracking : []).map((stage: any, index: number) => ({
      id: String(stage.id || index), title: stage.stage || '', description: stage.description || '',
      status: stage.status === 'COMPLETED' ? 'completed' : stage.status === 'CURRENT' ? 'current' : 'pending',
    })),
    currentStep: Math.min(Number(data.application?.currentStep || 0), 7),
    paymentStatus: payment?.paymentStatus === 'PAID' ? 'Paid' : 'Pending',
    status: data.application?.status || 'Draft',
    createdAt: data.application?.createdAt || new Date().toISOString(),
  };
};

const toPersonRequest = (person: Record<string, any>, personType: string) => ({
  ...person,
  id: undefined,
  personType,
  dob: person.dob || null,
});

const isDatabaseId = (id: string) => /^\d+$/.test(id);

export const useCompanyRegistrationStore = create<CompanyRegistrationState>((set, get) => ({
  draft: createEmptyDraft(),
  setCompanyType: (type) =>
    set((state) => {
      const isOpc = type === 'One Person Company (OPC)';
      let directors = state.draft.directors;
      if (isOpc && directors.length > 0) {
        directors = [{ ...directors[0], sharesPercentage: 100 }];
      }
      return {
        draft: {
          ...state.draft,
          company: { ...state.draft.company, companyType: type },
          directors,
        },
      };
    }),
  updateCompanyDetails: (details) =>
    set((state) => ({
      draft: {
        ...state.draft,
        company: { ...state.draft.company, ...details },
      },
    })),
  addDirector: (director) =>
    set((state) => {
      if (state.draft.company.companyType === 'One Person Company (OPC)') {
        return state; // Prevent adding more than 1 director/promoter for OPC
      }
      return {
        draft: {
          ...state.draft,
          directors: [...state.draft.directors, director],
        },
      };
    }),
  updateDirector: (id, updatedFields) =>
    set((state) => ({
      draft: {
        ...state.draft,
        directors: state.draft.directors.map((d) => (d.id === id ? { ...d, ...updatedFields } : d)),
      },
    })),
  removeDirector: (id) =>
    set((state) => ({
      draft: {
        ...state.draft,
        directors: state.draft.directors.filter((d) => d.id !== id),
      },
    })),
  addPartner: (partner) =>
    set((state) => ({
      draft: {
        ...state.draft,
        partners: [...state.draft.partners, partner],
      },
    })),
  removePartner: (id) =>
    set((state) => ({
      draft: {
        ...state.draft,
        partners: state.draft.partners.filter((p) => p.id !== id),
      },
    })),
  setOpcNominee: (opcNominee) =>
    set((state) => ({
      draft: { ...state.draft, opcNominee },
    })),
  toggleLinkedRegistration: (key) =>
    set((state) => ({
      draft: {
        ...state.draft,
        linkedRegistrations: {
          ...state.draft.linkedRegistrations,
          [key]: !state.draft.linkedRegistrations[key],
        },
      },
    })),
  updateDocumentStatus: (documentId, status, fileUri, fileName) =>
    set((state) => {
      const exists = state.draft.documents.some((doc) => doc.id === documentId);
      const updatedDocs = exists
        ? state.draft.documents.map((doc) => (doc.id === documentId ? { ...doc, status, fileUri, fileName } : doc))
        : [...state.draft.documents, { id: documentId, name: documentId, category: 'Conditional Doc', required: true, status, fileUri, fileName }];
      return {
        draft: {
          ...state.draft,
          documents: updatedDocs,
        },
      };
    }),
  setStep: (currentStep) =>
    set((state) => ({
      draft: { ...state.draft, currentStep },
    })),
  saveCurrentStep: async (step) => {
    const draft = get().draft;
    if (step === 0) {
      const application = await companyRegistrationApi.createOrUpdate(draft.id || undefined, draft.company.companyType, 1);
      set((state) => ({
        draft: { ...state.draft, id: String(application.id), currentStep: application.currentStep },
      }));
      return;
    }

    if (!draft.id) throw new Error('Company registration draft has not been created. Go back and continue from Company Type.');
    const applicationId = draft.id;

    if (step === 1) {
      await companyRegistrationApi.saveCompanyDetails(applicationId, draft.company);
      return;
    }

    if (step === 2) {
      const existingDocuments = await companyRegistrationApi.documents(applicationId);
      const officeFiles = [
        { id: 'OFFICE_UTILITY_BILL' as const, name: draft.company.officeAddressProofName, fileUri: draft.company.officeAddressProofUri, required: true },
        { id: 'REGISTERED_OFFICE_PROOF' as const, name: draft.company.ownershipDocName, fileUri: draft.company.ownershipDocUri, required: true },
        { id: 'PROPERTY_OWNER_NOC' as const, name: draft.company.ownerNocName, fileUri: draft.company.ownerNocUri, required: false },
      ];
      for (const file of officeFiles) {
        const matches = existingDocuments.filter((item) => item.documentType === file.id);
        if (file.fileUri) {
          await companyRegistrationApi.uploadDocument(applicationId, {
            id: file.id,
            name: file.name || file.id,
            category: 'Registered Office',
            required: file.required,
            status: 'Uploaded',
            fileUri: file.fileUri,
            fileName: file.name,
          });
          get().updateDocumentStatus(file.id, 'Uploaded', undefined, file.name);
        } else if (!file.name?.trim()) {
          for (const item of matches) await companyRegistrationApi.deleteDocument(applicationId, item.id);
          get().updateDocumentStatus(file.id, 'Pending', undefined, undefined);
        }
      }
      await companyRegistrationApi.saveRegisteredOffice(applicationId, draft.company);
      return;
    }

    if (step === 3) {
      const existing = await companyRegistrationApi.persons(applicationId);
      const retainedIds = new Set<number>();
      const savedDirectors: typeof draft.directors = [];
      const savedPartners: typeof draft.partners = [];

      const savePerson = async (person: Record<string, any>, personType: string) => {
        const request = toPersonRequest(person, personType);
        const personId = Number(person.id);
        const exists = isDatabaseId(String(person.id)) && existing.some((item) => Number(item.id) === personId);
        const saved = exists
          ? await companyRegistrationApi.updatePerson(applicationId, personId, request)
          : await companyRegistrationApi.addPerson(applicationId, request);
        retainedIds.add(Number(saved.id));
        return saved;
      };

      for (const director of draft.directors) {
        const saved = await savePerson(director as unknown as Record<string, any>, 'DIRECTOR');
        savedDirectors.push({ ...director, ...saved, id: String(saved.id) });
      }
      for (const partner of draft.partners) {
        const saved = await savePerson(partner as unknown as Record<string, any>, 'PARTNER');
        savedPartners.push({ ...partner, ...saved, id: String(saved.id) });
      }
      if (draft.opcNominee) {
        await savePerson(draft.opcNominee as unknown as Record<string, any>, 'NOMINEE');
      }

      for (const person of existing) {
        if (!retainedIds.has(Number(person.id))) {
          await companyRegistrationApi.deletePerson(applicationId, person.id);
        }
      }

      set((state) => ({
        draft: { ...state.draft, directors: savedDirectors, partners: savedPartners },
      }));
      await companyRegistrationApi.createOrUpdate(applicationId, draft.company.companyType, 4);
      return;
    }

    if (step === 4) {
      const existing = await companyRegistrationApi.shareholdings(applicationId);
      const byName = new Map<string, Record<string, any>[]>();
      for (const item of existing) {
        const name = String(item.person || '');
        byName.set(name, [...(byName.get(name) || []), item]);
      }

      const desired = [
        ...draft.directors.map((person) => ({
          person: person.name,
          numberOfShares: Number(person.numberOfShares || 0),
          shareValue: Number(person.amountSubscribed || 0),
          percentage: Number(person.sharesPercentage || 0),
        })),
        ...draft.partners.map((person) => ({
          person: person.name,
          numberOfShares: 0,
          shareValue: Number(person.capitalContribution || person.contributionAmount || 0),
          percentage: Number(person.profitSharePercentage || 0),
        })),
      ];
      const retainedIds = new Set<number>();
      for (const shareholding of desired) {
        const matching = byName.get(shareholding.person) || [];
        const stored = matching.shift();
        if (matching.length) byName.set(shareholding.person, matching);
        else byName.delete(shareholding.person);
        const saved = stored
          ? await companyRegistrationApi.updateShareholding(applicationId, stored.id, shareholding)
          : await companyRegistrationApi.addShareholding(applicationId, shareholding);
        retainedIds.add(Number(saved.id));
      }
      for (const item of existing) {
        if (!retainedIds.has(Number(item.id))) {
          await companyRegistrationApi.deleteShareholding(applicationId, item.id);
        }
      }
      await companyRegistrationApi.saveCapital(applicationId, draft.company);
      return;
    }

    if (step === 5) {
      const existing = await companyRegistrationApi.documents(applicationId);
      for (const document of draft.documents) {
        const matches = existing.filter((item) => item.documentType === document.id);
        if (document.status === 'Uploaded') {
          if (document.fileUri) {
            await companyRegistrationApi.uploadDocument(applicationId, document);
          } else if (!matches.some((item) => String(item.status).toUpperCase() === 'UPLOADED')) {
            throw new Error(`Select the file again for ${document.name} before saving.`);
          }
        } else {
          for (const item of matches) {
            await companyRegistrationApi.deleteDocument(applicationId, item.id);
          }
        }
      }
      await companyRegistrationApi.createOrUpdate(applicationId, draft.company.companyType, 6);
      return;
    }

    if (step === 6) {
      await companyRegistrationApi.saveLinkedRegistrations(applicationId, draft.linkedRegistrations);
      return;
    }

    if (step === 7) {
      const savedReview = await companyRegistrationApi.review(applicationId);
      set({ draft: { ...mapBackendDraft(savedReview), currentStep: 7 } });
      return;
    }

    throw new Error('Autosave is only enabled for the pre-payment wizard screens.');
  },
  processPayment: (_, applicationId) =>
    set((state) => ({
      draft: {
        ...state.draft,
        id: applicationId === undefined ? state.draft.id : String(applicationId),
        paymentStatus: 'Paid',
        status: 'Submitted',
      },
    })),
  hydrateFromBackend: async (applicationId, stepOverride) => {
    let id = applicationId;
    if (id === undefined) {
      const registrations = await companyRegistrationApi.list();
      const latestActive = registrations.find((registration) =>
        ['DRAFT', 'IN_PROGRESS'].includes(registration.status.toUpperCase()) &&
        Number(registration.currentStep || 0) <= 7
      );
      if (!latestActive) return;
      id = latestActive.id;
    }
    const details = await companyRegistrationApi.get(id);
    const hydrated = mapBackendDraft(details);
    set({ draft: { ...hydrated, ...(stepOverride === undefined ? {} : { currentStep: stepOverride }) } });
  },
  resetRegistration: () => set({ draft: createEmptyDraft() }),
}));


