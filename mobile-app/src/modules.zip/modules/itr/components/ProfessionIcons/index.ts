export { ProfessionIcon } from "./ProfessionIcons";
