export { ProfessionCard } from "./ProfessionCard";
