export { VerifiedSplashScreen } from "./VerifiedSplashScreen";
