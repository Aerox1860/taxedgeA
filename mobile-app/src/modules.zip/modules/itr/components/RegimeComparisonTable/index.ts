export { RegimeComparisonTable } from "./RegimeComparisonTable";
