import { create } from 'zustand';
import type { CompanyRegistrationDraft, LinkedRegistrations, CompanyDoc, CompanyDocumentType } from '../types/registration.types';
import type { CompanyType, CompanyDetails } from '../types/company.types';
import type { DirectorInfo, OpcNomineeInfo, PartnerInfo } from '../types/director.types';
import type { DocumentStatus } from '../../../types/domain';
import { companyRegistrationApi } from '../services/companyRegistrationApi';

interface CompanyRegistrationState {
  draft: CompanyRegistrationDraft;
  setCompanyType: (type: CompanyType) => void;
  updateCompanyDetails: (details: Partial<CompanyDetails>) => void;
  addDirector: (director: DirectorInfo) => void;
  updateDirector: (id: string, director: Partial<DirectorInfo>) => void;
  removeDirector: (id: string) => void;
  addPartner: (partner: PartnerInfo) => void;
  removePartner: (id: string) => void;
  setOpcNominee: (nominee: OpcNomineeInfo) => void;
  toggleLinkedRegistration: (key: keyof LinkedRegistrations) => void;
  updateDocumentStatus: (documentId: CompanyDocumentType, status: DocumentStatus, fileUri?: string, fileName?: string) => void;
  setStep: (step: number) => void;
  processPayment: (paymentMethod: string) => void;
  hydrateFromBackend: () => Promise<void>;
  resetRegistration: () => void;
}

const createEmptyDraft = (): CompanyRegistrationDraft => ({
  id: '',
  company: {
    companyType: 'Private Limited',
    companyClass: 'Private',
    companyCategory: 'Company limited by Shares',
    companySubCategory: 'Indian Non-Government Company',
    primaryActivity: '',
    nicCode: '',
    secondaryActivity: '',
    proposedName1: '',
    proposedName2: '',
    nameSuffix: '',
    registeredAddressLine: '',
    registeredCity: '',
    registeredDistrict: '',
    registeredState: '',
    registeredPincode: '',
    premisesOwnership: 'Owned',
    companyEmail: '',
    companyMobile: '',
    authorizedCapital: 0,
    paidUpCapital: 0,
    numberOfShares: 0,
    faceValuePerShare: 0,
  },
  directors: [],
  partners: [],
  documents: [
    { id: 'DIRECTOR_PAN', name: 'PAN Card of all Directors / Promoters', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'DIRECTOR_ID_PROOF', name: 'Aadhaar / Passport / Voter ID', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'REGISTERED_OFFICE_PROOF', name: 'Registered Office Ownership / Lease Proof', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'OFFICE_UTILITY_BILL', name: 'Utility Bill (Electricity / Water)', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'PROPERTY_OWNER_NOC', name: 'Property Owner No Objection Certificate (NOC)', category: 'Office Proof', required: false, status: 'Pending' },
  ],
  linkedRegistrations: {
    pan: false,
    tan: false,
    gst: false,
    esic: false,
    epfo: false,
    professionalTax: false,
    bankAccount: false,
  },
  feeBreakdown: {
    professionalFee: 0,
    gstAmount: 0,
    statutoryCharges: 0,
    totalAmount: 0,
  },
  trackingStages: [],
  currentStep: 0,
  totalFee: 0,
  paymentStatus: 'Pending',
  status: 'Draft',
  createdAt: new Date().toISOString(),
});

const initialDraft: CompanyRegistrationDraft = {
  id: 'INC-2026-89421',
  company: {
    companyType: 'Private Limited',
    companyClass: 'Private',
    companyCategory: 'Company limited by Shares',
    companySubCategory: 'Indian Non-Government Company',
    primaryActivity: 'Information Technology & Software Services',
    nicCode: '62011',
    secondaryActivity: 'Data Processing & Hosting Services',
    proposedName1: 'TaxEdge Tech Private Limited',
    proposedName2: 'TaxEdge Financial Innovations Pvt Ltd',
    proposedName3: 'TaxEdge Solutions Private Limited',
    nameSuffix: 'Private Limited',
    nameAvailabilityStatus: 'Available',
    registeredAddressLine: 'Plot 42, Tech Park Phase 2, HITEC City',
    registeredCity: 'Hyderabad',
    registeredDistrict: 'Rangareddy',
    registeredState: 'Telangana',
    registeredPincode: '500081',
    premisesOwnership: 'Rented',
    companyEmail: 'contact@taxedgetech.com',
    companyMobile: '9876543210',
    officeAddressProofName: 'Electricity_Bill.pdf',
    officeAddressProofUri: '',
    ownershipDocName: 'Rent_Agreement_Office.pdf',
    ownershipDocUri: '',
    ownerNocName: 'Owner_NOC.pdf',
    ownerNocUri: '',
    authorizedCapital: 100000,
    paidUpCapital: 100000,
    numberOfShares: 10000,
    faceValuePerShare: 10,
  },
  directors: [
    {
      id: 'dir-1',
      name: 'Rajesh Kumar',
      pan: 'ABCDE1234F',
      aadhaar: '123456789012',
      dob: '1988-05-14',
      fatherName: 'Suresh Kumar',
      gender: 'Male',
      nationality: 'Indian',
      placeOfBirth: 'Hyderabad',
      occupation: 'Professional',
      educationalQualification: 'Post Graduate',
      designation: 'Director',
      category: 'Promoter Director',
      email: 'rajesh@taxedge.com',
      phone: '9876543210',
      hasDin: true,
      din: '08492014',
      hasDsc: true,
      sharesPercentage: 60,
      residentialAddress: 'Flat 302, Green Acres, Hyderabad',
      addressLine1: 'Flat 302, Green Acres, Road No 12',
      city: 'Hyderabad',
      district: 'Rangareddy',
      state: 'Telangana',
      pinCode: '500034',
      isResidentInIndia: true,
      sameAsPermanentAddress: true,
      numberOfShares: 6000,
      amountSubscribed: 60000,
      identityProofDocName: 'Aadhaar_Card_Rajesh.pdf',
      residentialAddressProofDocName: 'Passport_Rajesh.pdf',
    },
    {
      id: 'dir-2',
      name: 'Anita Sharma',
      pan: 'XYZPS9876K',
      aadhaar: '987654321098',
      dob: '1990-11-20',
      fatherName: 'Ramesh Sharma',
      gender: 'Female',
      nationality: 'Indian',
      placeOfBirth: 'Hyderabad',
      occupation: 'Business',
      educationalQualification: 'Graduate',
      designation: 'Director',
      category: 'Promoter Director',
      email: 'anita@taxedge.com',
      phone: '9812345678',
      hasDin: false,
      hasDsc: true,
      sharesPercentage: 40,
      residentialAddress: 'H.No 12-4, Jubliee Hills, Hyderabad',
      addressLine1: 'H.No 12-4, Jubilee Hills, Road No 36',
      city: 'Hyderabad',
      district: 'Hyderabad',
      state: 'Telangana',
      pinCode: '500033',
      isResidentInIndia: true,
      sameAsPermanentAddress: true,
      numberOfShares: 4000,
      amountSubscribed: 40000,
      identityProofDocName: 'Aadhaar_Card_Anita.pdf',
      residentialAddressProofDocName: '',
    },
  ],
  opcNominee: {
    name: 'Vikram Sharma',
    pan: 'NOMEE4321P',
    aadhaar: '456789123045',
    email: 'vikram.nominee@taxedge.com',
    phone: '9765432109',
    relationship: 'Brother',
  },
  partners: [],
  documents: [
    { id: 'DIRECTOR_PAN', name: 'PAN Card of all Directors / Promoters', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'DIRECTOR_ID_PROOF', name: 'Aadhaar / Passport / Voter ID', category: 'Promoter KYC', required: true, status: 'Pending' },
    { id: 'REGISTERED_OFFICE_PROOF', name: 'Registered Office Ownership / Lease Proof', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'OFFICE_UTILITY_BILL', name: 'Utility Bill (Electricity / Water)', category: 'Office Proof', required: true, status: 'Pending' },
    { id: 'PROPERTY_OWNER_NOC', name: 'Property Owner No Objection Certificate (NOC)', category: 'Office Proof', required: false, status: 'Pending' },
  ],
  linkedRegistrations: {
    pan: true,
    tan: true,
    gst: true,
    esic: true,
    epfo: true,
    professionalTax: true,
    bankAccount: true,
  },
  feeBreakdown: {
    professionalFee: 4999,
    gstAmount: 900,
    statutoryCharges: 1500,
    totalAmount: 7399,
  },
  trackingStages: [
    { id: 'stg-1', title: 'Draft Creation', description: 'Application initiated by user', status: 'completed', updatedAt: '18 Sep 2026' },
    { id: 'stg-2', title: 'KYC & Document Verification', description: 'Reviewing PAN, Aadhaar & Office Proofs', status: 'completed', updatedAt: '18 Sep 2026' },
    { id: 'stg-3', title: 'Under Review', description: 'TaxEdge compliance expert validation', status: 'current', updatedAt: 'In Progress' },
    { id: 'stg-4', title: 'Name Reservation (RUN / SPICe+ Part A)', description: 'Filing preferred names with MCA CRC', status: 'pending' },
    { id: 'stg-5', title: 'DSC & DIN Processing', description: 'Digital signature token generation', status: 'pending' },
    { id: 'stg-6', title: 'Ready for SPICe+ Part B Filing', description: 'Final incorporation payload compilation', status: 'pending' },
    { id: 'stg-7', title: 'Submitted to MCA Portal', description: 'Form e-MoA, e-AoA & AGILE-PRO-S filed', status: 'pending' },
    { id: 'stg-8', title: 'Government Approval & COI', description: 'Certificate of Incorporation & CIN Issuance', status: 'pending' },
  ],
  currentStep: 0,
  totalFee: 4999,
  paymentStatus: 'Pending',
  status: 'Draft',
  createdAt: '2026-09-18',
};

const mapBackendDraft = (data: any): CompanyRegistrationDraft => {
  const base = createEmptyDraft();
  const company = data.companyDetails || {};
  const office = data.registeredOffice || {};
  const capital = data.capital || {};
  const people = Array.isArray(data.persons) ? data.persons : [];
  const payments = Array.isArray(data.payments) ? data.payments : [];
  const payment = payments[0];

  return {
    ...base,
    id: String(data.application?.id || ''),
    company: {
      ...base.company,
      ...company,
      companyType: data.application?.companyType || company.companyType || base.company.companyType,
      registeredAddressLine: office.addressLine || '',
      registeredCity: office.city || '',
      registeredDistrict: office.district || '',
      registeredState: office.state || '',
      registeredPincode: office.pincode || '',
      premisesOwnership: office.premisesOwnership || 'Owned',
      officeAddressProofName: office.officeAddressProofName,
      officeAddressProofUri: office.officeAddressProofUri,
      ownershipDocName: office.ownershipDocName,
      ownershipDocUri: office.ownershipDocUri,
      ownerNocName: office.ownerNocName,
      ownerNocUri: office.ownerNocUri,
      authorizedCapital: Number(capital.authorizedCapital ?? company.authorizedCapital ?? 0),
      paidUpCapital: Number(capital.paidUpCapital ?? company.paidUpCapital ?? 0),
      numberOfShares: Number(capital.numberOfShares ?? company.numberOfShares ?? 0),
      faceValuePerShare: Number(capital.faceValuePerShare ?? company.faceValuePerShare ?? 0),
    } as CompanyRegistrationDraft['company'],
    directors: people.filter((person: any) => person.personType !== 'PARTNER' && person.personType !== 'NOMINEE').map((person: any) => ({
      ...person,
      id: String(person.id),
    })),
    partners: people.filter((person: any) => person.personType === 'PARTNER').map((person: any) => ({
      id: String(person.id), name: person.name, pan: person.pan, aadhaar: person.aadhaar || '', email: person.email, phone: person.phone || '',
      contributionAmount: Number(person.contributionAmount || 0), profitSharePercentage: Number(person.profitSharePercentage || 0),
      capitalContribution: Number(person.capitalContribution || 0), profitSharingRatio: Number(person.profitSharingRatio || 0),
    })),
    documents: (Array.isArray(data.documents) ? data.documents : []).map((document: any) => ({
      id: document.documentType as CompanyDocumentType,
      name: document.name || document.documentType,
      category: document.category || '',
      required: Boolean(document.required),
      status: String(document.status).toUpperCase() === 'UPLOADED' ? 'Uploaded' : 'Pending',
      fileUri: document.fileUri,
      fileName: document.fileName,
    })) as CompanyDoc[],
    linkedRegistrations: { ...base.linkedRegistrations, ...(data.linkedRegistrations || {}) },
    feeBreakdown: {
      professionalFee: Number(payment?.professionalFee || 0),
      gstAmount: 0,
      statutoryCharges: Number(payment?.governmentFee || 0),
      totalAmount: Number(payment?.totalAmount || 0),
    },
    trackingStages: (Array.isArray(data.tracking) ? data.tracking : []).map((stage: any, index: number) => ({
      id: String(stage.id || index), title: stage.stage || '', description: stage.description || '',
      status: stage.status === 'COMPLETED' ? 'completed' : stage.status === 'CURRENT' ? 'current' : 'pending',
    })),
    currentStep: Number(data.application?.currentStep || 0),
    paymentStatus: payment?.paymentStatus === 'PAID' ? 'Paid' : 'Pending',
    status: data.application?.status || 'Draft',
    createdAt: data.application?.createdAt || new Date().toISOString(),
  };
};

export const useCompanyRegistrationStore = create<CompanyRegistrationState>((set) => ({
  draft: createEmptyDraft(),
  setCompanyType: (type) =>
    set((state) => {
      const isOpc = type === 'One Person Company (OPC)';
      let directors = state.draft.directors;
      if (isOpc && directors.length > 0) {
        directors = [{ ...directors[0], sharesPercentage: 100 }];
      }
      return {
        draft: {
          ...state.draft,
          company: { ...state.draft.company, companyType: type },
          directors,
        },
      };
    }),
  updateCompanyDetails: (details) =>
    set((state) => ({
      draft: {
        ...state.draft,
        company: { ...state.draft.company, ...details },
      },
    })),
  addDirector: (director) =>
    set((state) => {
      if (state.draft.company.companyType === 'One Person Company (OPC)') {
        return state; // Prevent adding more than 1 director/promoter for OPC
      }
      return {
        draft: {
          ...state.draft,
          directors: [...state.draft.directors, director],
        },
      };
    }),
  updateDirector: (id, updatedFields) =>
    set((state) => ({
      draft: {
        ...state.draft,
        directors: state.draft.directors.map((d) => (d.id === id ? { ...d, ...updatedFields } : d)),
      },
    })),
  removeDirector: (id) =>
    set((state) => ({
      draft: {
        ...state.draft,
        directors: state.draft.directors.filter((d) => d.id !== id),
      },
    })),
  addPartner: (partner) =>
    set((state) => ({
      draft: {
        ...state.draft,
        partners: [...state.draft.partners, partner],
      },
    })),
  removePartner: (id) =>
    set((state) => ({
      draft: {
        ...state.draft,
        partners: state.draft.partners.filter((p) => p.id !== id),
      },
    })),
  setOpcNominee: (opcNominee) =>
    set((state) => ({
      draft: { ...state.draft, opcNominee },
    })),
  toggleLinkedRegistration: (key) =>
    set((state) => ({
      draft: {
        ...state.draft,
        linkedRegistrations: {
          ...state.draft.linkedRegistrations,
          [key]: !state.draft.linkedRegistrations[key],
        },
      },
    })),
  updateDocumentStatus: (documentId, status, fileUri, fileName) =>
    set((state) => {
      const exists = state.draft.documents.some((doc) => doc.id === documentId);
      const updatedDocs = exists
        ? state.draft.documents.map((doc) => (doc.id === documentId ? { ...doc, status, fileUri, fileName } : doc))
        : [...state.draft.documents, { id: documentId, name: documentId, category: 'Conditional Doc', required: true, status, fileUri, fileName }];
      return {
        draft: {
          ...state.draft,
          documents: updatedDocs,
        },
      };
    }),
  setStep: (currentStep) =>
    set((state) => ({
      draft: { ...state.draft, currentStep },
    })),
  processPayment: () =>
    set((state) => ({
      draft: {
        ...state.draft,
        paymentStatus: 'Paid',
        status: 'Submitted',
      },
    })),
  hydrateFromBackend: async () => {
    const registrations = await companyRegistrationApi.list();
    if (!registrations.length) return;
    const latest = registrations[0];
    const details = await companyRegistrationApi.get(latest.id);
    set({ draft: mapBackendDraft(details) });
  },
  resetRegistration: () => set({ draft: createEmptyDraft() }),
}));


