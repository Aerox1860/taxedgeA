import { apiClient } from "../../../core/api/apiClient";
import type { CompanyDoc, CompanyRegistrationDraft } from "../types/registration.types";

type ApplicationResponse = { applicationId: string | number; applicationNumber?: string; status: string };
type RegistrationSummary = { id: number; applicationNumber: string; companyType: string; status: string; currentStep: number };
type RegistrationDetails = {
  application: RegistrationSummary;
  companyDetails: Record<string, any>;
  registeredOffice: Record<string, any>;
  persons: any[];
  capital: Record<string, any>;
  shareholdings: any[];
  documents: any[];
  linkedRegistrations: Record<string, boolean>;
  payments: any[];
  tracking: any[];
};

export const companyRegistrationApi = {
  list: async () => apiClient.get<RegistrationSummary[]>('/api/v1/company-registrations'),
  get: async (applicationId: string | number) =>
    apiClient.get<RegistrationDetails>(`/api/v1/company-registrations/${applicationId}`),
  submitApplication: async (draft: CompanyRegistrationDraft) => {
    return apiClient.post<ApplicationResponse>(
      "/company-registration/apply",
      draft
    );
  },
  uploadDocument: async (applicationId: string | number, document: CompanyDoc) => {
    if (!document.fileUri) throw new Error(`File is missing for ${document.id}`);
    const form = new FormData();
    form.append("documentType", document.id);
    form.append("file", {
      uri: document.fileUri,
      name: document.fileName || `${document.id}.bin`,
      type: document.fileName?.toLowerCase().endsWith(".pdf") ? "application/pdf" : "image/jpeg",
    } as any);
    return apiClient.post(`/api/v1/company-registrations/${applicationId}/documents`, form);
  },
  savePayment: async (applicationId: string | number, payload: {
    amount: number;
    governmentFee: number;
    professionalFee: number;
    totalAmount: number;
    paymentStatus: string;
    transactionId: string;
    paymentGateway: string;
    paymentMethod: string;
  }) => apiClient.post(`/api/v1/company-registrations/${applicationId}/payment`, payload),
  submitRegistration: async (applicationId: string | number) =>
    apiClient.post<ApplicationResponse>(`/api/v1/company-registrations/${applicationId}/submit`),
  checkNameAvailability: async (proposedName: string) => {
    return apiClient.get<{ available: boolean; similarNames: string[] }>(
      "/company-registration/check-name",
      { params: { name: proposedName } }
    );
  },
  fetchStatus: async (applicationId: string) => {
    return apiClient.get<{ status: string; currentStage: string }>(
      `/company-registration/status/${applicationId}`
    );
  },
};

export default companyRegistrationApi;
